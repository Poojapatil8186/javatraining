package com.example.movielsportslogindemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovielsportslogindemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
