package com.example.webassingementdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebassingementdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebassingementdemoApplication.class, args);
	}

}
