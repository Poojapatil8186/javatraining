package com.example.assingementjpahtml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssingementjpahtmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssingementjpahtmlApplication.class, args);
	}

}
