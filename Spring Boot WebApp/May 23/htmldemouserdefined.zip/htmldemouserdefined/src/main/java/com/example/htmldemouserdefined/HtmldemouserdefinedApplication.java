package com.example.htmldemouserdefined;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmldemouserdefinedApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmldemouserdefinedApplication.class, args);
	}

}
