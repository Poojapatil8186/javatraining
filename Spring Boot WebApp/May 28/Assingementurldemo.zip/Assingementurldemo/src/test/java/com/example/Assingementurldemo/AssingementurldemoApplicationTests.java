package com.example.Assingementurldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssingementurldemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
