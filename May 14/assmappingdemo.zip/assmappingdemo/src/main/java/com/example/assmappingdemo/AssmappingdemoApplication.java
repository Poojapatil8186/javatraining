package com.example.assmappingdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssmappingdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssmappingdemoApplication.class, args);
	}

}
