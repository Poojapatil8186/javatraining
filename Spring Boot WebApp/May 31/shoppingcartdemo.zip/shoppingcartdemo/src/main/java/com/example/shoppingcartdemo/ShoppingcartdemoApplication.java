package com.example.shoppingcartdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingcartdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingcartdemoApplication.class, args);
	}

}
