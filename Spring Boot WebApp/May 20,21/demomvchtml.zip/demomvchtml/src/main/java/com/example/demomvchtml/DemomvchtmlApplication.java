package com.example.demomvchtml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomvchtmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomvchtmlApplication.class, args);
	}

}
