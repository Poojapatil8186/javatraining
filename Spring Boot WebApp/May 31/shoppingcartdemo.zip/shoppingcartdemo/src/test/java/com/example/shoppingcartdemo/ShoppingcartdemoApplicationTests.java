package com.example.shoppingcartdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingcartdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
