package com.example.mappingdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MappingdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
