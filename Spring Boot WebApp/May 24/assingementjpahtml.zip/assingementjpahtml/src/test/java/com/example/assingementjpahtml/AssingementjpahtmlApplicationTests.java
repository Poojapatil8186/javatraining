package com.example.assingementjpahtml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssingementjpahtmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
