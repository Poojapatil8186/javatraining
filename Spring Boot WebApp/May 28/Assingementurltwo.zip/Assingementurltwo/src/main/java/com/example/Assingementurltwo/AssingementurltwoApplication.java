package com.example.Assingementurltwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssingementurltwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssingementurltwoApplication.class, args);
	}

}
