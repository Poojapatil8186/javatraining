package com.example.assmappingdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssmappingdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
