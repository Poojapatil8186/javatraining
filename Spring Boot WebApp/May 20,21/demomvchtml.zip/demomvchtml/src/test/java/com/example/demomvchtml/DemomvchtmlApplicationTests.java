package com.example.demomvchtml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomvchtmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
