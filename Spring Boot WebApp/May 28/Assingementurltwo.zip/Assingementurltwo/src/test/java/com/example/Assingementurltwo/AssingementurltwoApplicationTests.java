package com.example.Assingementurltwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssingementurltwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
