package com.example.demohttpmethod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemohttpmethodApplicationTests {

	@Test
	void contextLoads() {
	}

}
